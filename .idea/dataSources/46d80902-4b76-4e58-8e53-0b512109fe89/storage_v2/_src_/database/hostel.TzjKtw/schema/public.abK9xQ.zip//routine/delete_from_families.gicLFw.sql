create function delete_from_families()
  returns trigger
language plpgsql
as $$
begin
  delete from families where fk_parent = old.id;
  return old;
end;
$$;

alter function delete_from_families()
  owner to postgres;

