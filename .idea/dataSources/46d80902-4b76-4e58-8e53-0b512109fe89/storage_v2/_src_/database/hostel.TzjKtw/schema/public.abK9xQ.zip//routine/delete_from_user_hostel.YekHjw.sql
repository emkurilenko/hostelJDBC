create function delete_from_user_hostel()
  returns trigger
language plpgsql
as $$
begin
  delete from user_hostel where fk_user_id = old.id;
  return old;
end;
$$;

alter function delete_from_user_hostel()
  owner to postgres;

