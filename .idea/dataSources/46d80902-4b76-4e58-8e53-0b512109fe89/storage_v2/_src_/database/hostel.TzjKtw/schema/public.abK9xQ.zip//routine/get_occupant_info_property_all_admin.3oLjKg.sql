create function get_occupant_info_property_all_admin()
  returns TABLE(id_occupant integer, first_name character varying, middle_name character varying, last_name character varying, room_number integer, type_cccupant character varying)
language plpgsql
as $$
declare var_r record;
begin
  for var_r in (select occupant.id          as id,
                       occupant.first_name  as first_name,
                       occupant.middle_name as middle_name,
                       occupant.last_name   as last_name,
                       occupant.occupant_type,
                       r.number_room
                from occupant as occupant
                       inner join contract c2 on occupant.id = c2.fk_occupant
                       inner join settlement s2 on c2.id = s2.fk_contract
                       inner join room r on s2.fk_room = r.id
               )
  loop
    id_occupant := var_r.id;
    first_name := var_r.first_name;
    middle_name := var_r.middle_name;
    last_name := var_r.last_name;
    room_number := var_r.number_room;
    type_cccupant := var_r.occupant_type;
    RETURN NEXT;
  end loop;
end
$$;

alter function get_occupant_info_property_all_admin()
  owner to postgres;

