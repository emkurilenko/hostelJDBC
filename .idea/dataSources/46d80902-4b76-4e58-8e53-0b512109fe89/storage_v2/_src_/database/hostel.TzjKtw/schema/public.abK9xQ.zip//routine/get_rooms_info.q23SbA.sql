create function get_rooms_info(hostelid integer)
  returns TABLE(id integer, numberroom integer, floornumber integer, roomspecification character varying, occupiedbeds integer, numberofbeds integer)
language plpgsql
as $$
declare var_r record;
begin
  for var_r in(
      select r.id, r.number_room, r.floor, specification.type_of_room as sp,r.number as occupiedBeds,specification.numberofbeds as numberofbeds from room r
                                         inner join room_specification specification on r.fk_room_specification = specification.id
                                         where r.fk_hostel = hostelId
  )
  loop
    id := var_r.id;
    numberRoom := var_r.number_room;
    floorNumber := var_r.floor;
    roomSpecification := var_r.sp;
    occupiedBeds := var_r.occupiedBeds;
    numberofbeds := var_r.numberofbeds;
    RETURN NEXT;
  end loop;
end
$$;

alter function get_rooms_info(integer)
  owner to postgres;

