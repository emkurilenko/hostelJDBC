create function insert_into_employees(_id bigint, _fk_department bigint, _number_of_family bigint, OUT _id_employees integer)
  returns integer
language plpgsql
as $$
begin
  insert into employees (id, fk_department, numberoffamilymembers) VALUES (_id, _fk_department, _number_of_family) returning id into _id_employees;
end
$$;

alter function insert_into_employees(bigint, bigint, bigint, out integer)
  owner to postgres;

