create function insert_into_department(_namedepartment character varying, _namefaculty character varying, OUT _id_department integer)
  returns integer
language plpgsql
as $$
declare faculty_id integer :=(select id from faculty where name_faculty = _nameFaculty);
begin
  if exists(select dep.id
            from department dep
            where dep.name_department = _nameDepartment
              and dep.id_faculty = faculty_id)
  then
    raise notice 'The department exists!';
  else
    insert into department (name_department, id_faculty)
    values (_nameDepartment, faculty_id) returning id into _id_department;
  end if;
end
$$;

alter function insert_into_department(varchar, varchar, out integer)
  owner to postgres;

