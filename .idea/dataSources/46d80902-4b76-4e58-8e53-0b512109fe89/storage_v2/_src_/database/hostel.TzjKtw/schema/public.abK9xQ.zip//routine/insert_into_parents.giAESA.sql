create function insert_into_parents(_id_student bigint, _first_name character varying, _middle_name character varying, _last_name character varying, _status character varying, OUT _id_parents integer)
  returns integer
language plpgsql
as $$
begin
  insert into parents(id, first_name, middle_name, last_name, status) values (default, _first_name, _middle_name, _last_name, _status) returning id into _id_parents;
  insert into families(id, fk_parent, fk_student) values (default, _id_parents, _id_student);
end
$$;

alter function insert_into_parents(bigint, varchar, varchar, varchar, varchar, out integer)
  owner to postgres;

