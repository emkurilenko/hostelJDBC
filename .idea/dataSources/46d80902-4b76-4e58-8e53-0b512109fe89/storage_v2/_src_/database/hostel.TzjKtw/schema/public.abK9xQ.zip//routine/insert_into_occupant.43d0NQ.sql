create function insert_into_occupant(_first_name character varying, _middle_name character varying, _last_name character varying, _date_of_birth date, _telephone character varying, _gender character varying, _occupant_type character varying, OUT _id_occupant integer)
  returns integer
language plpgsql
as $$
begin
  if (exists(select first_name, middle_name, last_name
             from occupant
             where first_name = _first_name
               and middle_name = _middle_name
               and last_name = _last_name))
  then
    raise notice 'The Occupant exists!';
  else
    insert into occupant (id, first_name, middle_name, last_name, date_of_birth, telephone, gender, occupant_type)
    VALUES (default,
            _first_name,
            _middle_name,
            _last_name,
            _date_of_birth,
            _telephone,
            _gender,
            _occupant_type) returning id
      into _id_occupant;
  end if;
end
$$;

alter function insert_into_occupant(varchar, varchar, varchar, date, varchar, varchar, varchar, out integer)
  owner to postgres;

