create function get_user_info_all()
  returns TABLE(id_user integer, username character varying, user_role character varying, hostel_name character varying)
language plpgsql
as $$
declare var_r record;
begin
  for var_r in (select us.id as id, us.username as username, us.user_role as user_role, h2.name_hostel as hostename
                from users us
                       inner join user_hostel ushostel on us.id = ushostel.fk_user_id
                       inner join hostels h2 on ushostel.fk_hostel_id = h2.id
               )
  loop
    id_user := var_r.id;
    username := var_r.username;
    user_role := var_r.user_role;
    hostel_name := var_r.hostename;
    RETURN NEXT;
  end loop;
end
$$;

alter function get_user_info_all()
  owner to postgres;

