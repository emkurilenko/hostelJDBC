create function create_new_user_without_hostel(_username character varying, _password character varying, _namehsotel character varying, OUT _id_user integer)
  returns integer
language plpgsql
as $$
declare hostel_id integer := (select id from hostels where name_hostel = _nameHsotel);
begin
  if (exists(select id from hostels where name_hostel = _nameHsotel))
  then
    raise notice 'Hostel not found';
  else
    if exists(select _user.id from users _user where _user.username = _username)
    then
      raise notice 'The user exists!';
    else
      insert into users (username, password) values (_username, _password) returning id
        into _id_user;
      insert into user_hostel (fk_user_id, fk_hostel_id) values (_id_user, hostel_id);
    end if;
  end if;
end
$$;

alter function create_new_user_without_hostel(varchar, varchar, varchar, out integer)
  owner to postgres;

