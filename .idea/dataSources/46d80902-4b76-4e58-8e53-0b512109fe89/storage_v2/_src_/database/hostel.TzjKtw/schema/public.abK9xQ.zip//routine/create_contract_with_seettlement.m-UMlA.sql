create function create_contract_with_seettlement(_id_occupant bigint, _number character varying, _date_of_conolution date, _date_of_settlement date, _date_of_evcition date, _id_room bigint, OUT _id_contract integer)
  returns integer
language plpgsql
as $$
begin
  if (exists(select * from contract where number = _number))
  then
    raise notice 'The Contract exists!';
  else
    insert into contract values (default, _number, _date_of_conolution, _id_occupant) returning id
      into _id_contract;
    insert into settlement values (_id_contract, _date_of_settlement, _date_of_evcition, _id_room);
  end if;
end
$$;

alter function create_contract_with_seettlement(bigint, varchar, date, date, date, bigint, out integer)
  owner to postgres;

