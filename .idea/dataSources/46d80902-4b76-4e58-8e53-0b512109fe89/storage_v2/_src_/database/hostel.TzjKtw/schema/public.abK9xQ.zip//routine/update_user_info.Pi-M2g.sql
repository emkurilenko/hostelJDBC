create function update_user_info(_id bigint, _username character varying, _password character varying, _user_role character varying, _namehsotel character varying, OUT _id_user integer)
  returns integer
language plpgsql
as $$
declare hostel_id integer := (select id from hostels where name_hostel = _nameHsotel);
begin
   update users as us set username = _username, password = _password, user_role = _user_role where us.id = _id returning us.id into _id_user;
   update user_hostel set fk_hostel_id = (select hs.id from hostels as hs where hs.name_hostel = _nameHsotel) where fk_user_id = _id_user;
end
$$;

alter function update_user_info(bigint, varchar, varchar, varchar, varchar, out integer)
  owner to postgres;

