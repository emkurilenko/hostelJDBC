create function insert_into_specialty(_namespecialty character varying, _namedepartment character varying, OUT _id_specialty integer)
  returns integer
language plpgsql
as $$
declare department_id integer :=(select id from department where name_department = _nameDepartment);
begin
  if exists(select spc.id
            from specialty spc
            where spc.name_specialty = _nameSpecialty
              and spc.id_department = department_id)
  then
    raise notice 'The department exists!';
  else
    insert into specialty (name_specialty, id_department)
    values (_nameSpecialty, department_id) returning id into _id_specialty;
  end if;
end
$$;

alter function insert_into_specialty(varchar, varchar, out integer)
  owner to postgres;

