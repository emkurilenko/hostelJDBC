create function insert_into_student(_id bigint, _record_number character varying, _fk_group bigint, OUT _id_student integer)
  returns integer
language plpgsql
as $$
begin
  insert into student (id, record_number, fk_group) VALUES (_id, _record_number, _fk_group) returning id into _id_student;
end
$$;

alter function insert_into_student(bigint, varchar, bigint, out integer)
  owner to postgres;

